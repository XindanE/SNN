// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xsnn_quant.h"

extern XSnn_quant_Config XSnn_quant_ConfigTable[];

XSnn_quant_Config *XSnn_quant_LookupConfig(u16 DeviceId) {
	XSnn_quant_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSNN_QUANT_NUM_INSTANCES; Index++) {
		if (XSnn_quant_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSnn_quant_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSnn_quant_Initialize(XSnn_quant *InstancePtr, u16 DeviceId) {
	XSnn_quant_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSnn_quant_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSnn_quant_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

