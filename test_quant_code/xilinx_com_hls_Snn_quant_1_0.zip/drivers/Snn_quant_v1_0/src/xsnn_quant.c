// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xsnn_quant.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSnn_quant_CfgInitialize(XSnn_quant *InstancePtr, XSnn_quant_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->Max_BaseAddress = ConfigPtr->Max_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSnn_quant_Start(XSnn_quant *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_quant_ReadReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSnn_quant_WriteReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSnn_quant_IsDone(XSnn_quant *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_quant_ReadReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSnn_quant_IsIdle(XSnn_quant *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_quant_ReadReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSnn_quant_IsReady(XSnn_quant *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_quant_ReadReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSnn_quant_EnableAutoRestart(XSnn_quant *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_quant_WriteReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSnn_quant_DisableAutoRestart(XSnn_quant *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_quant_WriteReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_AP_CTRL, 0);
}

void XSnn_quant_Set_inp_offset(XSnn_quant *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_quant_WriteReg(InstancePtr->Control_r_BaseAddress, XSNN_QUANT_CONTROL_R_ADDR_INP_OFFSET_DATA, (u32)(Data));
    XSnn_quant_WriteReg(InstancePtr->Control_r_BaseAddress, XSNN_QUANT_CONTROL_R_ADDR_INP_OFFSET_DATA + 4, (u32)(Data >> 32));
}

u64 XSnn_quant_Get_inp_offset(XSnn_quant *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_quant_ReadReg(InstancePtr->Control_r_BaseAddress, XSNN_QUANT_CONTROL_R_ADDR_INP_OFFSET_DATA);
    Data += (u64)XSnn_quant_ReadReg(InstancePtr->Control_r_BaseAddress, XSNN_QUANT_CONTROL_R_ADDR_INP_OFFSET_DATA + 4) << 32;
    return Data;
}

u32 XSnn_quant_Get_max_index(XSnn_quant *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_quant_ReadReg(InstancePtr->Max_BaseAddress, XSNN_QUANT_MAX_ADDR_MAX_INDEX_DATA);
    return Data;
}

u32 XSnn_quant_Get_max_index_vld(XSnn_quant *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_quant_ReadReg(InstancePtr->Max_BaseAddress, XSNN_QUANT_MAX_ADDR_MAX_INDEX_CTRL);
    return Data & 0x1;
}

void XSnn_quant_InterruptGlobalEnable(XSnn_quant *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_quant_WriteReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_GIE, 1);
}

void XSnn_quant_InterruptGlobalDisable(XSnn_quant *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_quant_WriteReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_GIE, 0);
}

void XSnn_quant_InterruptEnable(XSnn_quant *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSnn_quant_ReadReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_IER);
    XSnn_quant_WriteReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_IER, Register | Mask);
}

void XSnn_quant_InterruptDisable(XSnn_quant *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSnn_quant_ReadReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_IER);
    XSnn_quant_WriteReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSnn_quant_InterruptClear(XSnn_quant *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_quant_WriteReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_ISR, Mask);
}

u32 XSnn_quant_InterruptGetEnabled(XSnn_quant *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSnn_quant_ReadReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_IER);
}

u32 XSnn_quant_InterruptGetStatus(XSnn_quant *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSnn_quant_ReadReg(InstancePtr->Control_BaseAddress, XSNN_QUANT_CONTROL_ADDR_ISR);
}

