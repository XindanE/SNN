// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xsnn_lif.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSnn_lif_CfgInitialize(XSnn_lif *InstancePtr, XSnn_lif_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->Max_BaseAddress = ConfigPtr->Max_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSnn_lif_Start(XSnn_lif *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSnn_lif_IsDone(XSnn_lif *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSnn_lif_IsIdle(XSnn_lif *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSnn_lif_IsReady(XSnn_lif *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSnn_lif_EnableAutoRestart(XSnn_lif *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSnn_lif_DisableAutoRestart(XSnn_lif *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL, 0);
}

void XSnn_lif_Set_inp_offset(XSnn_lif *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_lif_WriteReg(InstancePtr->Control_r_BaseAddress, XSNN_LIF_CONTROL_R_ADDR_INP_OFFSET_DATA, (u32)(Data));
    XSnn_lif_WriteReg(InstancePtr->Control_r_BaseAddress, XSNN_LIF_CONTROL_R_ADDR_INP_OFFSET_DATA + 4, (u32)(Data >> 32));
}

u64 XSnn_lif_Get_inp_offset(XSnn_lif *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_lif_ReadReg(InstancePtr->Control_r_BaseAddress, XSNN_LIF_CONTROL_R_ADDR_INP_OFFSET_DATA);
    Data += (u64)XSnn_lif_ReadReg(InstancePtr->Control_r_BaseAddress, XSNN_LIF_CONTROL_R_ADDR_INP_OFFSET_DATA + 4) << 32;
    return Data;
}

u32 XSnn_lif_Get_max_index(XSnn_lif *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_lif_ReadReg(InstancePtr->Max_BaseAddress, XSNN_LIF_MAX_ADDR_MAX_INDEX_DATA);
    return Data;
}

u32 XSnn_lif_Get_max_index_vld(XSnn_lif *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_lif_ReadReg(InstancePtr->Max_BaseAddress, XSNN_LIF_MAX_ADDR_MAX_INDEX_CTRL);
    return Data & 0x1;
}

void XSnn_lif_InterruptGlobalEnable(XSnn_lif *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_GIE, 1);
}

void XSnn_lif_InterruptGlobalDisable(XSnn_lif *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_GIE, 0);
}

void XSnn_lif_InterruptEnable(XSnn_lif *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_IER);
    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_IER, Register | Mask);
}

void XSnn_lif_InterruptDisable(XSnn_lif *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_IER);
    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSnn_lif_InterruptClear(XSnn_lif *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_ISR, Mask);
}

u32 XSnn_lif_InterruptGetEnabled(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_IER);
}

u32 XSnn_lif_InterruptGetStatus(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_ISR);
}

