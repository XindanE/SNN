// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xsnn_lif.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSnn_lif_CfgInitialize(XSnn_lif *InstancePtr, XSnn_lif_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSnn_lif_Start(XSnn_lif *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSnn_lif_IsDone(XSnn_lif *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSnn_lif_IsIdle(XSnn_lif *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSnn_lif_IsReady(XSnn_lif *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSnn_lif_EnableAutoRestart(XSnn_lif *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSnn_lif_DisableAutoRestart(XSnn_lif *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XSnn_lif_Get_spike_sum_BaseAddress(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_BASE);
}

u32 XSnn_lif_Get_spike_sum_HighAddress(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_HIGH);
}

u32 XSnn_lif_Get_spike_sum_TotalBytes(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_HIGH - XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_BASE + 1);
}

u32 XSnn_lif_Get_spike_sum_BitWidth(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSNN_LIF_CONTROL_WIDTH_SPIKE_SUM;
}

u32 XSnn_lif_Get_spike_sum_Depth(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSNN_LIF_CONTROL_DEPTH_SPIKE_SUM;
}

u32 XSnn_lif_Write_spike_sum_Words(XSnn_lif *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_HIGH - XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XSnn_lif_Read_spike_sum_Words(XSnn_lif *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_HIGH - XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_BASE + (offset + i)*4);
    }
    return length;
}

u32 XSnn_lif_Write_spike_sum_Bytes(XSnn_lif *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_HIGH - XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XSnn_lif_Read_spike_sum_Bytes(XSnn_lif *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_HIGH - XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_BASE + offset + i);
    }
    return length;
}

u32 XSnn_lif_Get_inp_BaseAddress(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XSNN_LIF_CONTROL_ADDR_INP_BASE);
}

u32 XSnn_lif_Get_inp_HighAddress(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XSNN_LIF_CONTROL_ADDR_INP_HIGH);
}

u32 XSnn_lif_Get_inp_TotalBytes(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XSNN_LIF_CONTROL_ADDR_INP_HIGH - XSNN_LIF_CONTROL_ADDR_INP_BASE + 1);
}

u32 XSnn_lif_Get_inp_BitWidth(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSNN_LIF_CONTROL_WIDTH_INP;
}

u32 XSnn_lif_Get_inp_Depth(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSNN_LIF_CONTROL_DEPTH_INP;
}

u32 XSnn_lif_Write_inp_Words(XSnn_lif *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XSNN_LIF_CONTROL_ADDR_INP_HIGH - XSNN_LIF_CONTROL_ADDR_INP_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XSNN_LIF_CONTROL_ADDR_INP_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XSnn_lif_Read_inp_Words(XSnn_lif *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XSNN_LIF_CONTROL_ADDR_INP_HIGH - XSNN_LIF_CONTROL_ADDR_INP_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XSNN_LIF_CONTROL_ADDR_INP_BASE + (offset + i)*4);
    }
    return length;
}

u32 XSnn_lif_Write_inp_Bytes(XSnn_lif *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XSNN_LIF_CONTROL_ADDR_INP_HIGH - XSNN_LIF_CONTROL_ADDR_INP_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XSNN_LIF_CONTROL_ADDR_INP_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XSnn_lif_Read_inp_Bytes(XSnn_lif *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XSNN_LIF_CONTROL_ADDR_INP_HIGH - XSNN_LIF_CONTROL_ADDR_INP_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XSNN_LIF_CONTROL_ADDR_INP_BASE + offset + i);
    }
    return length;
}

void XSnn_lif_InterruptGlobalEnable(XSnn_lif *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_GIE, 1);
}

void XSnn_lif_InterruptGlobalDisable(XSnn_lif *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_GIE, 0);
}

void XSnn_lif_InterruptEnable(XSnn_lif *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_IER);
    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_IER, Register | Mask);
}

void XSnn_lif_InterruptDisable(XSnn_lif *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_IER);
    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSnn_lif_InterruptClear(XSnn_lif *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSnn_lif_WriteReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_ISR, Mask);
}

u32 XSnn_lif_InterruptGetEnabled(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_IER);
}

u32 XSnn_lif_InterruptGetStatus(XSnn_lif *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSnn_lif_ReadReg(InstancePtr->Control_BaseAddress, XSNN_LIF_CONTROL_ADDR_ISR);
}

