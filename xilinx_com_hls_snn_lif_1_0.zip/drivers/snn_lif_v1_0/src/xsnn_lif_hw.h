// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// CONTROL
// 0x000 : Control signals
//         bit 0  - ap_start (Read/Write/COH)
//         bit 1  - ap_done (Read/COR)
//         bit 2  - ap_idle (Read)
//         bit 3  - ap_ready (Read/COR)
//         bit 7  - auto_restart (Read/Write)
//         bit 9  - interrupt (Read)
//         others - reserved
// 0x004 : Global Interrupt Enable Register
//         bit 0  - Global Interrupt Enable (Read/Write)
//         others - reserved
// 0x008 : IP Interrupt Enable Register (Read/Write)
//         bit 0 - enable ap_done interrupt (Read/Write)
//         bit 1 - enable ap_ready interrupt (Read/Write)
//         others - reserved
// 0x00c : IP Interrupt Status Register (Read/TOW)
//         bit 0 - ap_done (Read/TOW)
//         bit 1 - ap_ready (Read/TOW)
//         others - reserved
// 0x020 ~
// 0x03f : Memory 'spike_sum' (10 * 16b)
//         Word n : bit [15: 0] - spike_sum[2n]
//                  bit [31:16] - spike_sum[2n+1]
// 0x400 ~
// 0x7ff : Memory 'inp' (784 * 8b)
//         Word n : bit [ 7: 0] - inp[4n]
//                  bit [15: 8] - inp[4n+1]
//                  bit [23:16] - inp[4n+2]
//                  bit [31:24] - inp[4n+3]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSNN_LIF_CONTROL_ADDR_AP_CTRL        0x000
#define XSNN_LIF_CONTROL_ADDR_GIE            0x004
#define XSNN_LIF_CONTROL_ADDR_IER            0x008
#define XSNN_LIF_CONTROL_ADDR_ISR            0x00c
#define XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_BASE 0x020
#define XSNN_LIF_CONTROL_ADDR_SPIKE_SUM_HIGH 0x03f
#define XSNN_LIF_CONTROL_WIDTH_SPIKE_SUM     16
#define XSNN_LIF_CONTROL_DEPTH_SPIKE_SUM     10
#define XSNN_LIF_CONTROL_ADDR_INP_BASE       0x400
#define XSNN_LIF_CONTROL_ADDR_INP_HIGH       0x7ff
#define XSNN_LIF_CONTROL_WIDTH_INP           8
#define XSNN_LIF_CONTROL_DEPTH_INP           784

