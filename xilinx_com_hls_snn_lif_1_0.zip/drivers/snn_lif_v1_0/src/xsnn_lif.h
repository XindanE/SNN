// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XSNN_LIF_H
#define XSNN_LIF_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xsnn_lif_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XSnn_lif_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XSnn_lif;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XSnn_lif_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XSnn_lif_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XSnn_lif_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XSnn_lif_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XSnn_lif_Initialize(XSnn_lif *InstancePtr, UINTPTR BaseAddress);
XSnn_lif_Config* XSnn_lif_LookupConfig(UINTPTR BaseAddress);
#else
int XSnn_lif_Initialize(XSnn_lif *InstancePtr, u16 DeviceId);
XSnn_lif_Config* XSnn_lif_LookupConfig(u16 DeviceId);
#endif
int XSnn_lif_CfgInitialize(XSnn_lif *InstancePtr, XSnn_lif_Config *ConfigPtr);
#else
int XSnn_lif_Initialize(XSnn_lif *InstancePtr, const char* InstanceName);
int XSnn_lif_Release(XSnn_lif *InstancePtr);
#endif

void XSnn_lif_Start(XSnn_lif *InstancePtr);
u32 XSnn_lif_IsDone(XSnn_lif *InstancePtr);
u32 XSnn_lif_IsIdle(XSnn_lif *InstancePtr);
u32 XSnn_lif_IsReady(XSnn_lif *InstancePtr);
void XSnn_lif_EnableAutoRestart(XSnn_lif *InstancePtr);
void XSnn_lif_DisableAutoRestart(XSnn_lif *InstancePtr);

u32 XSnn_lif_Get_spike_sum_BaseAddress(XSnn_lif *InstancePtr);
u32 XSnn_lif_Get_spike_sum_HighAddress(XSnn_lif *InstancePtr);
u32 XSnn_lif_Get_spike_sum_TotalBytes(XSnn_lif *InstancePtr);
u32 XSnn_lif_Get_spike_sum_BitWidth(XSnn_lif *InstancePtr);
u32 XSnn_lif_Get_spike_sum_Depth(XSnn_lif *InstancePtr);
u32 XSnn_lif_Write_spike_sum_Words(XSnn_lif *InstancePtr, int offset, word_type *data, int length);
u32 XSnn_lif_Read_spike_sum_Words(XSnn_lif *InstancePtr, int offset, word_type *data, int length);
u32 XSnn_lif_Write_spike_sum_Bytes(XSnn_lif *InstancePtr, int offset, char *data, int length);
u32 XSnn_lif_Read_spike_sum_Bytes(XSnn_lif *InstancePtr, int offset, char *data, int length);
u32 XSnn_lif_Get_inp_BaseAddress(XSnn_lif *InstancePtr);
u32 XSnn_lif_Get_inp_HighAddress(XSnn_lif *InstancePtr);
u32 XSnn_lif_Get_inp_TotalBytes(XSnn_lif *InstancePtr);
u32 XSnn_lif_Get_inp_BitWidth(XSnn_lif *InstancePtr);
u32 XSnn_lif_Get_inp_Depth(XSnn_lif *InstancePtr);
u32 XSnn_lif_Write_inp_Words(XSnn_lif *InstancePtr, int offset, word_type *data, int length);
u32 XSnn_lif_Read_inp_Words(XSnn_lif *InstancePtr, int offset, word_type *data, int length);
u32 XSnn_lif_Write_inp_Bytes(XSnn_lif *InstancePtr, int offset, char *data, int length);
u32 XSnn_lif_Read_inp_Bytes(XSnn_lif *InstancePtr, int offset, char *data, int length);

void XSnn_lif_InterruptGlobalEnable(XSnn_lif *InstancePtr);
void XSnn_lif_InterruptGlobalDisable(XSnn_lif *InstancePtr);
void XSnn_lif_InterruptEnable(XSnn_lif *InstancePtr, u32 Mask);
void XSnn_lif_InterruptDisable(XSnn_lif *InstancePtr, u32 Mask);
void XSnn_lif_InterruptClear(XSnn_lif *InstancePtr, u32 Mask);
u32 XSnn_lif_InterruptGetEnabled(XSnn_lif *InstancePtr);
u32 XSnn_lif_InterruptGetStatus(XSnn_lif *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
