// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xsnn_lif.h"

extern XSnn_lif_Config XSnn_lif_ConfigTable[];

#ifdef SDT
XSnn_lif_Config *XSnn_lif_LookupConfig(UINTPTR BaseAddress) {
	XSnn_lif_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XSnn_lif_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XSnn_lif_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XSnn_lif_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSnn_lif_Initialize(XSnn_lif *InstancePtr, UINTPTR BaseAddress) {
	XSnn_lif_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSnn_lif_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSnn_lif_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XSnn_lif_Config *XSnn_lif_LookupConfig(u16 DeviceId) {
	XSnn_lif_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSNN_LIF_NUM_INSTANCES; Index++) {
		if (XSnn_lif_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSnn_lif_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSnn_lif_Initialize(XSnn_lif *InstancePtr, u16 DeviceId) {
	XSnn_lif_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSnn_lif_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSnn_lif_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

